# Glass Launcher

Launcher Android bertema glassmorphism ("Glassy Dashboard V5") untuk Xiaomi Pad 6S Pro, dengan **Workstation mode**.

## Fitur
- Home: sapaan, kartu statistik, favorit
- Apps: grid + pencarian, tahan lama untuk pin ke dock
- Wallpaper custom (di-blur)
- **Workstation mode**: desktop + taskbar + Start menu, app dibuka sebagai window mengambang

## Build
- GitHub Actions: tab **Actions** > **Build APK** > unduh artifact `GlassLauncher-debug`
- Lokal: buka di Android Studio lalu Run

## Workstation mode (freeform)
Aktifkan di Developer options: **Enable freeform windows** dan **Force activities to be resizable**, lalu restart.

## Stack
Kotlin, Jetpack Compose, minSdk 31
