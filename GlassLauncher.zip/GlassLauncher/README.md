# Liquid Desk

Launcher Android bergaya desktop (ala Samsung DeX) dengan tema liquid glass, untuk Xiaomi Pad 6S Pro.

- Desktop: ikon pinned, widget jam, background liquid beranimasi (atau wallpaper sendiri, tahan lama di area kosong)
- Taskbar: tombol Start, app pinned, tray baterai + jam
- Start menu: pencarian + semua app
- App dibuka sebagai window mengambang bertingkat (butuh freeform di Developer options)

Build: tab Actions > Build APK > unduh artifact GlassLauncher-debug.
