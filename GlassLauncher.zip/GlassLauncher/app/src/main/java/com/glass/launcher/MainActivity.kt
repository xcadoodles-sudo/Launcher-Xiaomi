package com.glass.launcher

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LauncherApp() }
    }
}

class AppItem(val label: String, val pkg: String, val icon: ImageBitmap)

// ---------- LIQUID GLASS ----------
fun Modifier.liquid(shape: Shape = RoundedCornerShape(28.dp), a: Float = .16f): Modifier =
    clip(shape)
        .background(Brush.verticalGradient(listOf(Color.White.copy(a + .10f), Color.White.copy((a - .06f).coerceAtLeast(.02f)))))
        .drawWithContent {
            drawRect(Brush.verticalGradient(0f to Color.White.copy(.20f), .4f to Color.Transparent))
            drawContent()
        }
        .border(1.2.dp, Brush.linearGradient(listOf(Color.White.copy(.75f), Color.White.copy(.08f), Color.White.copy(.35f))), shape)

@Composable
fun LiquidBackground(bg: ImageBitmap?) {
    if (bg != null) {
        Image(bg, null, Modifier.fillMaxSize().blur(4.dp, BlurredEdgeTreatment.Unbounded), contentScale = ContentScale.Crop)
        return
    }
    val t = rememberInfiniteTransition(label = "bg")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(26000, easing = LinearEasing)), label = "p")
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF0B1026), Color(0xFF1A1040), Color(0xFF0E2A3A))))
        val w = size.width
        val h = size.height
        val a = p * 2f * PI.toFloat()
        fun blob(c: Color, cx: Float, cy: Float, r: Float) =
            drawCircle(brush = Brush.radialGradient(listOf(c, Color.Transparent), Offset(cx, cy), r), radius = r, center = Offset(cx, cy))
        blob(Color(0xFF00E5FF).copy(.50f), w * (.22f + .12f * sin(a)), h * (.30f + .10f * cos(a)), h * .60f)
        blob(Color(0xFF8B5CF6).copy(.55f), w * (.70f + .10f * cos(a)), h * (.28f + .12f * sin(a)), h * .65f)
        blob(Color(0xFFFF4FA3).copy(.40f), w * (.55f + .14f * sin(a + 2f)), h * (.80f + .06f * cos(a)), h * .55f)
        blob(Color(0xFFFF9F43).copy(.30f), w * (.10f + .08f * cos(a + 1f)), h * (.85f + .05f * sin(a)), h * .45f)
    }
}

// ---------- helpers ----------
fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(q, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm).toBitmap(160, 160).asImageBitmap()) }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun loadBg(ctx: Context): ImageBitmap? =
    File(ctx.filesDir, "bg.jpg").takeIf { it.exists() }?.let {
        BitmapFactory.decodeFile(it.path, BitmapFactory.Options().apply { inSampleSize = 2 })?.asImageBitmap()
    }

fun launchApp(ctx: Context, pkg: String, bounds: Rect?) {
    val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    val o = ActivityOptions.makeBasic()
    if (bounds != null) o.setLaunchBounds(bounds)
    ctx.startActivity(i, o.toBundle())
}

// ---------- ROOT ----------
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LauncherApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("glass", Context.MODE_PRIVATE) }
    var apps by remember { mutableStateOf(emptyList<AppItem>()) }
    var pinned by remember { mutableStateOf(prefs.getStringSet("pinned", emptySet())!!.toSet()) }
    var menu by remember { mutableStateOf(false) }
    var bg by remember { mutableStateOf(loadBg(ctx)) }
    var running by remember { mutableStateOf(setOf<String>()) }
    var win by remember { mutableIntStateOf(0) }
    val freeform = remember { Settings.Global.getInt(ctx.contentResolver, "enable_freeform_support", 0) == 1 }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { loadApps(ctx) }
        if (!prefs.contains("pinned")) {
            val want = listOf("com.android.chrome", "com.android.settings", "com.miui.gallery", "com.android.camera",
                "com.google.android.youtube", "com.whatsapp", "com.mi.android.globalFileexplorer", "com.google.android.apps.photos")
            var first = apps.filter { it.pkg in want }.map { it.pkg }
            if (first.size < 5) first = (first + apps.map { it.pkg }).distinct().take(6)
            pinned = first.toSet()
            prefs.edit().putStringSet("pinned", pinned).apply()
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            ctx.contentResolver.openInputStream(uri)?.use { i ->
                File(ctx.filesDir, "bg.jpg").outputStream().use { o -> i.copyTo(o) }
            }
            bg = loadBg(ctx)
        }
    }

    fun togglePin(a: AppItem) {
        pinned = if (a.pkg in pinned) pinned - a.pkg else pinned + a.pkg
        prefs.edit().putStringSet("pinned", pinned).apply()
    }
    fun open(a: AppItem) {
        menu = false
        val dm = ctx.resources.displayMetrics
        val w = (dm.widthPixels * .62f).toInt()
        val h = (dm.heightPixels * .70f).toInt()
        val off = 70 + (win % 6) * 64
        launchApp(ctx, a.pkg, Rect(off, off, off + w, off + h))
        win++
        running = running + a.pkg
    }

    val fav = apps.filter { it.pkg in pinned }
    val src = remember { MutableInteractionSource() }

    MaterialTheme(colorScheme = darkColorScheme()) {
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            Box(Modifier.fillMaxSize()) {
                LiquidBackground(bg)
                // area kosong desktop: tap = tutup menu, tahan lama = ganti wallpaper
                Box(Modifier.fillMaxSize().combinedClickable(src, null,
                    onLongClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    onClick = { menu = false }))
                Box(Modifier.fillMaxSize().systemBarsPadding()) {
                    LazyHorizontalGrid(GridCells.Adaptive(116.dp),
                        Modifier.fillMaxSize().padding(start = 16.dp, top = 16.dp, bottom = 100.dp, end = 320.dp)) {
                        items(fav, key = { it.pkg }) { AppIcon(it, 60.dp, true, false, { open(it) }, { togglePin(it) }) }
                    }
                    ClockWidget(Modifier.align(Alignment.TopEnd).padding(24.dp))
                    if (!freeform) Text("Freeform window belum aktif - nyalakan di Developer options",
                        Modifier.align(Alignment.TopCenter).padding(top = 12.dp).liquid(CircleShape).padding(horizontal = 16.dp, vertical = 8.dp),
                        fontSize = 12.sp)
                    AnimatedVisibility(menu, Modifier.align(Alignment.BottomStart).padding(start = 16.dp, bottom = 96.dp),
                        enter = fadeIn() + scaleIn(initialScale = .88f, transformOrigin = TransformOrigin(0f, 1f)),
                        exit = fadeOut() + scaleOut(targetScale = .88f, transformOrigin = TransformOrigin(0f, 1f))) {
                        StartMenu(apps, { open(it) }, { togglePin(it) }, Modifier.width(540.dp).height(580.dp))
                    }
                    Taskbar(Modifier.align(Alignment.BottomCenter).padding(horizontal = 16.dp, vertical = 12.dp),
                        menu, { menu = !menu }, fav, running, { open(it) }, { togglePin(it) })
                }
            }
        }
    }
}

// ---------- DESKTOP PARTS ----------
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIcon(a: AppItem, size: Dp, label: Boolean, dot: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) .86f else 1f, spring(.45f, 380f), label = "press")
    Box(Modifier.graphicsLayer { scaleX = s; scaleY = s }.clip(RoundedCornerShape(20.dp))
        .combinedClickable(src, null, onClick = onClick, onLongClick = onLong)) {
        Column(Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(a.icon, a.label, Modifier.size(size).clip(RoundedCornerShape(size * .26f)))
            if (label) Text(a.label, Modifier.widthIn(max = size + 44.dp).padding(top = 6.dp), fontSize = 12.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, style = TextStyle(shadow = Shadow(Color.Black.copy(.55f), Offset(0f, 2f), 8f)))
        }
        if (dot) Box(Modifier.align(Alignment.BottomCenter).size(5.dp).clip(CircleShape).background(Color.White))
    }
}

@Composable
fun ClockWidget(m: Modifier) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(10_000) } }
    Column(m.liquid(RoundedCornerShape(32.dp)).padding(horizontal = 28.dp, vertical = 18.dp)) {
        Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(now), fontSize = 56.sp, fontWeight = FontWeight.Light)
        Text(SimpleDateFormat("EEEE, d MMMM", Locale("id")).format(now), fontSize = 14.sp, color = Color.White.copy(.75f))
    }
}

@Composable
fun Taskbar(m: Modifier, menuOpen: Boolean, onMenu: () -> Unit, pinned: List<AppItem>, running: Set<String>,
            open: (AppItem) -> Unit, pin: (AppItem) -> Unit) {
    Row(m.fillMaxWidth().height(68.dp).liquid(RoundedCornerShape(34.dp), .2f).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        StartButton(menuOpen, onMenu)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.width(1.dp).height(28.dp).background(Color.White.copy(.25f)))
        LazyRow(Modifier.weight(1f).padding(horizontal = 6.dp), horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically) {
            items(pinned, key = { it.pkg }) { AppIcon(it, 40.dp, false, it.pkg in running, { open(it) }, { pin(it) }) }
        }
        Tray()
    }
}

@Composable
fun StartButton(on: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(48.dp).clip(CircleShape).background(Color.White.copy(if (on) .30f else .14f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(22.dp)) {
            val g = size.width / 3f
            for (i in 0..2) for (j in 0..2) drawCircle(Color.White, g * .24f, Offset(g * (i + .5f), g * (j + .5f)))
        }
    }
}

@Composable
fun Tray() {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(Date()) }
    var bat by remember { mutableIntStateOf(100) }
    var chg by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i != null) {
                bat = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                chg = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            }
            delay(15_000)
        }
    }
    Row(Modifier.clip(RoundedCornerShape(24.dp)).background(Color.White.copy(.10f)).padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(26.dp, 13.dp).border(1.2.dp, Color.White.copy(.8f), RoundedCornerShape(4.dp)).padding(2.dp)) {
                val c = if (chg) Color(0xFF30D158) else if (bat <= 20) Color(0xFFFF453A) else Color.White
                Box(Modifier.fillMaxHeight().fillMaxWidth(bat.coerceIn(0, 100) / 100f).clip(RoundedCornerShape(2.dp)).background(c))
            }
            Spacer(Modifier.width(6.dp))
            Text("$bat%", fontSize = 13.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(now), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(SimpleDateFormat("d MMM", Locale("id")).format(now), fontSize = 11.sp, color = Color.White.copy(.7f))
        }
    }
}

@Composable
fun StartMenu(apps: List<AppItem>, open: (AppItem) -> Unit, pin: (AppItem) -> Unit, m: Modifier) {
    var q by remember { mutableStateOf("") }
    val tint = Color.White.copy(.14f)
    Column(m.liquid(RoundedCornerShape(32.dp), .2f).padding(18.dp)) {
        TextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("Cari aplikasi") }, singleLine = true, shape = CircleShape,
            colors = TextFieldDefaults.colors(focusedContainerColor = tint, unfocusedContainerColor = tint,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent))
        Text("Tahan lama ikon untuk pin / lepas dari desktop", Modifier.padding(vertical = 10.dp), fontSize = 12.sp, color = Color.White.copy(.65f))
        LazyVerticalGrid(GridCells.Adaptive(92.dp), Modifier.weight(1f)) {
            items(apps.filter { it.label.contains(q, true) }, key = { it.pkg }) { AppIcon(it, 52.dp, true, false, { open(it) }, { pin(it) }) }
        }
    }
}
