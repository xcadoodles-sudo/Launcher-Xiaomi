package com.glass.launcher

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LauncherApp() }
    }
}

class AppItem(val label: String, val pkg: String, val icon: ImageBitmap)
enum class Screen { HOME, APPS }

private val Accent = Color(0xFFFF7A1A)

// ---------- helpers ----------
fun Modifier.glass(shape: Shape = RoundedCornerShape(24.dp), a: Float = .14f): Modifier =
    clip(shape).background(Color.White.copy(a))
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(.5f), Color.White.copy(.05f))), shape)

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(q, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm).toBitmap(128, 128).asImageBitmap()) }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun loadBg(ctx: Context): ImageBitmap? =
    File(ctx.filesDir, "bg.jpg").takeIf { it.exists() }?.let {
        BitmapFactory.decodeFile(it.path, BitmapFactory.Options().apply { inSampleSize = 2 })?.asImageBitmap()
    }

fun launchApp(ctx: Context, pkg: String, bounds: Rect?) {
    val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    val o = ActivityOptions.makeBasic()
    if (bounds != null) o.setLaunchBounds(bounds) // jadi window mengambang kalau freeform aktif
    ctx.startActivity(i, o.toBundle())
}

// ---------- root ----------
@Composable
fun LauncherApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("glass", Context.MODE_PRIVATE) }
    var apps by remember { mutableStateOf(emptyList<AppItem>()) }
    var pinned by remember { mutableStateOf(prefs.getStringSet("pinned", emptySet())!!.toSet()) }
    var workstation by remember { mutableStateOf(prefs.getBoolean("ws", false)) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var bg by remember { mutableStateOf(loadBg(ctx)) }
    var winCount by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadApps(ctx) } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            ctx.contentResolver.openInputStream(uri)?.use { i ->
                File(ctx.filesDir, "bg.jpg").outputStream().use { o -> i.copyTo(o) }
            }
            bg = loadBg(ctx)
        }
    }

    fun togglePin(a: AppItem) {
        pinned = if (a.pkg in pinned) pinned - a.pkg else pinned + a.pkg
        prefs.edit().putStringSet("pinned", pinned).apply()
    }
    fun setWs(v: Boolean) { workstation = v; prefs.edit().putBoolean("ws", v).apply() }
    fun open(a: AppItem) {
        if (workstation) {
            val dm = ctx.resources.displayMetrics
            val w = (dm.widthPixels * .62).toInt()
            val h = (dm.heightPixels * .72).toInt()
            val off = 80 + (winCount % 6) * 72
            launchApp(ctx, a.pkg, Rect(off, off, off + w, off + h))
            winCount++
        } else launchApp(ctx, a.pkg, null)
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            Box(Modifier.fillMaxSize().background(Color(0xFF1B1410))) {
                val b = bg
                if (b != null) {
                    Image(b, null, Modifier.fillMaxSize().blur(6.dp, BlurredEdgeTreatment.Unbounded), contentScale = ContentScale.Crop)
                } else {
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF3B4A6B), Color(0xFFB77B5A), Color(0xFF2A1F1A)))))
                }
                Box(Modifier.fillMaxSize().background(Color.Black.copy(.25f)))

                if (workstation) {
                    Workstation(apps, pinned, { setWs(false) }, { open(it) }, { togglePin(it) })
                } else {
                    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) {
                        TopBar(screen, { screen = it }, { setWs(true) },
                            { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) })
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.weight(1f)) {
                            Dock(apps.filter { it.pkg in pinned }, { open(it) }, { togglePin(it) })
                            Spacer(Modifier.width(16.dp))
                            Box(Modifier.weight(1f)) {
                                if (screen == Screen.HOME) Home(apps, pinned, { open(it) }, { togglePin(it) })
                                else AppsScreen(apps, { open(it) }, { togglePin(it) }, Modifier.fillMaxSize())
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------- normal mode ----------
@Composable
fun TopBar(screen: Screen, onScreen: (Screen) -> Unit, onWs: () -> Unit, onWall: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.glass(CircleShape).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Chip("Home", screen == Screen.HOME) { onScreen(Screen.HOME) }
            Chip("Apps", screen == Screen.APPS) { onScreen(Screen.APPS) }
            Chip("Workstation", false, true, onWs)
            Chip("Wallpaper", false, false, onWall)
        }
        Spacer(Modifier.weight(1f))
        Clock()
    }
}

@Composable
fun Chip(t: String, on: Boolean, accent: Boolean = false, onClick: () -> Unit) {
    val bgc = when {
        on -> Color.White.copy(.25f)
        accent -> Accent.copy(.85f)
        else -> Color.Transparent
    }
    Text(t, Modifier.clip(CircleShape).background(bgc).clickable(onClick = onClick)
        .padding(horizontal = 16.dp, vertical = 8.dp), fontSize = 14.sp, fontWeight = FontWeight.Medium)
}

@Composable
fun Clock() {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(10_000) } }
    Text(SimpleDateFormat("EEE d MMM  HH:mm", Locale("id")).format(now), fontSize = 14.sp)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIcon(a: AppItem, size: Dp, label: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(16.dp)).combinedClickable(onClick = onClick, onLongClick = onLong).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Image(a.icon, a.label, Modifier.size(size))
        if (label) Text(a.label, Modifier.widthIn(max = size + 28.dp).padding(top = 4.dp), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun Dock(items: List<AppItem>, open: (AppItem) -> Unit, pin: (AppItem) -> Unit) {
    LazyColumn(Modifier.fillMaxHeight().width(72.dp).glass(RoundedCornerShape(28.dp)).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        items(items) { AppIcon(it, 44.dp, false, { open(it) }, { pin(it) }) }
    }
}

@Composable
fun Stat(title: String, value: String, m: Modifier) {
    Column(m.glass().padding(16.dp)) {
        Text(title, fontSize = 13.sp, color = Color.White.copy(.65f))
        Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Home(apps: List<AppItem>, pinned: Set<String>, open: (AppItem) -> Unit, pin: (AppItem) -> Unit) {
    val ctx = LocalContext.current
    val bat = remember { (ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) }
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greet = when {
        h < 11 -> "Selamat pagi"
        h < 15 -> "Selamat siang"
        h < 18 -> "Selamat sore"
        else -> "Selamat malam"
    }
    val fav = apps.filter { it.pkg in pinned }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(greet, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Stat("Baterai", "$bat%", Modifier.weight(1f))
            Stat("Aplikasi", "${apps.size}", Modifier.weight(1f))
            Stat("Pinned", "${fav.size}", Modifier.weight(1f))
        }
        Column(Modifier.fillMaxWidth().weight(1f).glass().padding(16.dp)) {
            Text("Favorit", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            if (fav.isEmpty()) Text("Tahan lama ikon app di tab Apps untuk pin ke dock & taskbar.", fontSize = 13.sp, color = Color.White.copy(.65f))
            else AppGrid(fav, open, pin, Modifier.weight(1f))
        }
    }
}

@Composable
fun AppGrid(apps: List<AppItem>, open: (AppItem) -> Unit, pin: (AppItem) -> Unit, modifier: Modifier = Modifier) {
    LazyVerticalGrid(GridCells.Adaptive(92.dp), modifier) {
        items(apps, key = { it.pkg }) { AppIcon(it, 56.dp, true, { open(it) }, { pin(it) }) }
    }
}

@Composable
fun AppsScreen(apps: List<AppItem>, open: (AppItem) -> Unit, pin: (AppItem) -> Unit, modifier: Modifier) {
    var q by remember { mutableStateOf("") }
    val tint = Color.White.copy(.12f)
    Column(modifier.glass().padding(16.dp)) {
        TextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("Cari aplikasi") }, singleLine = true, shape = CircleShape,
            colors = TextFieldDefaults.colors(focusedContainerColor = tint, unfocusedContainerColor = tint,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent))
        Spacer(Modifier.height(12.dp))
        AppGrid(apps.filter { it.label.contains(q, true) }, open, pin, Modifier.weight(1f))
    }
}

// ---------- WORKSTATION MODE ----------
@Composable
fun Workstation(apps: List<AppItem>, pinned: Set<String>, exit: () -> Unit, open: (AppItem) -> Unit, pin: (AppItem) -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    val freeform = remember { Settings.Global.getInt(ctx.contentResolver, "enable_freeform_support", 0) == 1 }
    Box(Modifier.fillMaxSize().systemBarsPadding()) {
        Column(Modifier.padding(32.dp)) {
            Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), fontSize = 64.sp, fontWeight = FontWeight.Light)
            Text(SimpleDateFormat("EEEE, d MMMM", Locale("id")).format(Date()), fontSize = 16.sp, color = Color.White.copy(.7f))
        }
        if (!freeform) Text("Freeform window belum aktif - nyalakan di Developer options",
            Modifier.align(Alignment.TopCenter).padding(top = 12.dp).glass(CircleShape).padding(horizontal = 16.dp, vertical = 8.dp), fontSize = 12.sp)
        if (menu) AppsScreen(apps, { menu = false; open(it) }, pin,
            Modifier.align(Alignment.BottomStart).padding(start = 16.dp, bottom = 84.dp).width(460.dp).height(520.dp))
        Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp).glass(CircleShape, .2f).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Start", Modifier.clip(CircleShape).background(Accent).clickable { menu = !menu }.padding(horizontal = 18.dp, vertical = 10.dp), fontWeight = FontWeight.SemiBold)
            apps.filter { it.pkg in pinned }.forEach { AppIcon(it, 36.dp, false, { menu = false; open(it) }, { pin(it) }) }
            Text("Keluar", Modifier.clip(CircleShape).background(Color.White.copy(.15f)).clickable(onClick = exit).padding(horizontal = 14.dp, vertical = 10.dp), fontSize = 13.sp)
            Clock()
        }
    }
}
